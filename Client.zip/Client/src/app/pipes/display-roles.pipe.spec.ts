import { DisplayRolesPipe } from './display-roles.pipe';

describe('DisplayRolesPipe', () => {
  it('create an instance', () => {
    const pipe = new DisplayRolesPipe();
    expect(pipe).toBeTruthy();
  });
});
