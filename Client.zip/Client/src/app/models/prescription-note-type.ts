export class PrescriptionNoteType{
    prescriptionNoteTypeId:String;
    typeName:  Number
    constructor(prescriptionNoteTypeId:String,typeName:any){
        this.prescriptionNoteTypeId = prescriptionNoteTypeId; 
        this.typeName = typeName;
    }
}