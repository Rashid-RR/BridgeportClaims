export class ClaimNote{
    noteText:String;
    noteType:  String
    constructor(noteText:String,noteType:String){
        this.noteText = noteText; 
        this.noteType = noteType;
    }
}