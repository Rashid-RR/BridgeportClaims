import { FilterUserPipe } from './filter-user.pipe';

describe('FilterUserPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterUserPipe();
    expect(pipe).toBeTruthy();
  });
});
