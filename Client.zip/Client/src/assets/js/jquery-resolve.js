console.log(jQuery)
console.log($)
$.widget.bridge('uibutton', $.ui.button);